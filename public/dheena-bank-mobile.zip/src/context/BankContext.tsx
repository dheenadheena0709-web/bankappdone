import React, { createContext, useContext, useState, ReactNode, useEffect } from 'react';
import { INITIAL_LEDGER_TRANSACTIONS, Transaction, FIXED_BALANCE_DISPLAY } from '../constants/mockData';
import { BUSINESS_COMPANY_USER } from '../constants/corporateData';

export interface DebitCard {
  number: string;
  maskedNumber: string;
  cvv: string;
  expiry: string;
  status: 'Active' | 'Inactive' | 'Blocked';
}

export interface User {
  id: string;
  accountNo: string;
  accountNumber: string; // alias for accountNo
  fullAccountNumber: string;
  name: string;
  holderName: string; // alias for name
  accountName: string;
  accountType: string;
  balance: number;
  balanceText: string;
  currency: string;
  ifsc: string;
  branch: string;
  upiId: string;
  mobile: string;
  email: string;
  panNumber: string;
  employment: string;
  pin: string;
  password?: string;
  debitCard: DebitCard;
  transactions?: Transaction[];
  isBusiness?: boolean;
  companyName?: string;
  micrCode?: string;
  gstNumber?: string;
  cin?: string;
}

// Backward compatibility alias
export type UserAccount = User;

export interface LastPayment {
  recipient: string;
  amount: number;
  date: string;
  fromAccount: string;
  transactionId: string;
  reference: string;
  type: string;
}

interface BankContextType {
  isLoggedIn: boolean;
  setIsLoggedIn: (val: boolean) => void;
  currentUser: User;
  setCurrentUser: React.Dispatch<React.SetStateAction<User>>;
  userAccount: User;
  setUserAccount: React.Dispatch<React.SetStateAction<User>>;
  users: User[];
  setUsers: React.Dispatch<React.SetStateAction<User[]>>;
  addUser: (user: User) => void;
  switchUser: (userIdOrAccount: string) => User | null;
  loginWithPassword: (accountOrUsername: string, pass: string) => User | null;
  loginWithPin: (pin: string) => User | null;
  generateCardNumber: (bin?: string) => string;
  transactions: Transaction[];
  lastPayment: LastPayment | null;
  setLastPayment: (payment: LastPayment | null) => void;
  executeTransfer: (params: { recipient: string; amount: number; reference: string; transferType: string }) => LastPayment;
  executeBillPayment: (params: { billerName: string; consumerNo: string; amount: number }) => LastPayment;
  resetAccountData: () => void;
  showBalance: boolean;
  setShowBalance: (val: boolean) => void;
  activeNavTab: string;
  setActiveNavTab: (tab: string) => void;
  deviceFrame: boolean;
  setDeviceFrame: (val: boolean) => void;
  darkMode: boolean;
  setDarkMode: (val: boolean) => void;
  toggleDarkMode: () => void;
}

// Helpers for dynamic member cards and accounts
export const generateCardNumber = (bin = '4532'): string => {
  const b2 = Math.floor(1000 + Math.random() * 9000).toString();
  const b3 = Math.floor(1000 + Math.random() * 9000).toString();
  const b4 = Math.floor(1000 + Math.random() * 9000).toString();
  return `${bin} ${b2} ${b3} ${b4}`;
};

export const generateCVV = (): string => {
  return Math.floor(100 + Math.random() * 900).toString();
};

export const generateExpiry = (): string => {
  const futureYear = (new Date().getFullYear() + 4).toString().slice(-2);
  const month = String(Math.floor(1 + Math.random() * 12)).padStart(2, '0');
  return `${month}/${futureYear}`;
};

export const generateAccountNumber = (): string => {
  return '0021' + Math.floor(10000000 + Math.random() * 90000000).toString();
};

const getStoredUserBalance = (userId: string, defaultBal: number): number => {
  if (typeof window !== 'undefined' && window.localStorage) {
    const key = `hsbc_balance_${userId}`;
    const stored = localStorage.getItem(key);
    if (stored !== null && !isNaN(Number(stored))) {
      return Number(stored);
    }
    // Backwards compatibility for existing default user
    if (userId === 'user-001') {
      const legacy = localStorage.getItem('hsbc_balance') || localStorage.getItem('bank_balance');
      if (legacy !== null && !isNaN(Number(legacy)) && Number(legacy) >= 1000000000) {
        return Number(legacy);
      }
    }
  }
  return defaultBal;
};

// 1. EXISTING USER - DO NOT MODIFY (Preserved exactly as requested)
export const DEFAULT_USER: User = {
  id: 'user-001',
  accountNo: '002197782010',
  accountNumber: '002197782010',
  fullAccountNumber: '002197782010',
  name: 'Sirajudeen Mohamed Sharif',
  holderName: 'Sirajudeen Mohamed Sharif',
  accountName: 'SAVINGS ACCOUNT - PREMIER',
  accountType: 'Premier Savings Account',
  balance: getStoredUserBalance('user-001', 12000000000),
  balanceText: FIXED_BALANCE_DISPLAY,
  currency: 'INR',
  ifsc: 'HSBC0400002',
  branch: 'HSBC Fort Main Branch, Mumbai',
  upiId: 'sirajudeen.sharif@hsbc',
  mobile: '9677513691',
  email: '-',
  panNumber: 'FUCPS1419A',
  employment: 'Nil',
  pin: '696196',
  password: 'Password@123',
  debitCard: {
    number: '4532 8921 5409 4022',
    maskedNumber: '•••• •••• •••• 4022',
    cvv: '842',
    expiry: '09/29',
    status: 'Active'
  },
  transactions: INITIAL_LEDGER_TRANSACTIONS
};

// Active Users List - Sirajudeen only (Raja & Kumar completely deleted)
export const INITIAL_USERS: User[] = [DEFAULT_USER];

// Helper for future member creation (ready for 30 members)
export const createMemberUser = (params: {
  name: string;
  accountNo?: string;
  balance?: number;
  pin?: string;
  password?: string;
  mobile?: string;
  email?: string;
  panNumber?: string;
}): User => {
  const accountNo = params.accountNo || generateAccountNumber();
  const cardNum = generateCardNumber();
  const bal = params.balance !== undefined ? params.balance : 50000;
  return {
    id: `user-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
    accountNo,
    accountNumber: accountNo,
    fullAccountNumber: accountNo,
    name: params.name,
    holderName: params.name,
    accountName: `${params.name.toUpperCase()} - PREMIER`,
    accountType: 'Premier Savings Account',
    balance: bal,
    balanceText: bal.toLocaleString('en-IN'),
    currency: 'INR',
    ifsc: 'HSBC0400002',
    branch: 'HSBC Fort Main Branch, Mumbai',
    upiId: `${params.name.toLowerCase().replace(/\s+/g, '.')}@hsbc`,
    mobile: params.mobile || `98${Math.floor(10000000 + Math.random() * 90000000)}`,
    email: params.email || `${params.name.toLowerCase().replace(/\s+/g, '.')}@example.com`,
    panNumber: params.panNumber || 'ABCDE' + Math.floor(1000 + Math.random() * 9000) + 'F',
    employment: 'Salaried / Professional',
    pin: params.pin || '123456',
    password: params.password || params.pin || 'Password@123',
    debitCard: {
      number: cardNum,
      maskedNumber: `•••• •••• •••• ${cardNum.slice(-4)}`,
      cvv: generateCVV(),
      expiry: generateExpiry(),
      status: 'Active'
    },
    transactions: [
      {
        id: `tx-init-${Date.now()}`,
        date: '10/10/2026',
        time: '12:00 PM',
        senderName: 'Initial Account Deposit',
        transferMode: 'NEFT',
        status: 'Success',
        narration: `NEFT/INWARD DEPOSIT/ACCOUNT OPENING/${params.name.toUpperCase()}`,
        refNo: `NEFT-INIT-${Math.floor(100000 + Math.random() * 900000)}`,
        withdrawal: null,
        deposit: bal,
        balance: bal,
        category: 'Inward Remittance',
        type: 'credit',
        amountText: bal.toLocaleString('en-IN')
      }
    ]
  };
};

const BankContext = createContext<BankContextType | undefined>(undefined);

export const BankProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [isLoggedIn, setIsLoggedIn] = useState<boolean>(true);

  // Central Users List - strictly contains Sirajudeen. All test users (Raja & Kumar) permanently deleted.
  const [users, setUsers] = useState<User[]>(() => {
    if (typeof window !== 'undefined' && window.localStorage) {
      // Purge any stored references or balances of Raja and Kumar
      try {
        localStorage.removeItem('hsbc_users_list_v3');
        localStorage.removeItem('hsbc_users_list_v2');
        localStorage.removeItem('hsbc_users_list');
        localStorage.removeItem('hsbc_balance_user-002');
        localStorage.removeItem('hsbc_balance_user-003');
        const currentId = localStorage.getItem('hsbc_current_user_id');
        if (currentId === 'user-002' || currentId === 'user-003') {
          localStorage.setItem('hsbc_current_user_id', 'user-001');
        }
      } catch {
        // ignore
      }

      const stored = localStorage.getItem('hsbc_users_list_v4');
      if (stored) {
        try {
          const parsed = JSON.parse(stored);
          if (Array.isArray(parsed) && parsed.length > 0) {
            // Strictly exclude any traces of Raja or Kumar
            const sanitized = parsed.filter(
              (u) =>
                u.id !== 'user-002' &&
                u.id !== 'user-003' &&
                u.name?.toLowerCase() !== 'raja' &&
                u.name?.toLowerCase() !== 'kumar' &&
                u.pin !== '998877' &&
                u.pin !== '112233'
            );
            if (sanitized.length > 0) {
              return sanitized;
            }
          }
        } catch {
          // ignore error
        }
      }
    }
    return INITIAL_USERS;
  });

  // Central Current User State - defaults to Sirajudeen or active session
  const [currentUser, setCurrentUser] = useState<User>(() => {
    if (typeof window !== 'undefined' && window.localStorage) {
      const storedUserId = localStorage.getItem('hsbc_current_user_id');
      if (storedUserId === BUSINESS_COMPANY_USER.id) {
        return {
          ...BUSINESS_COMPANY_USER,
          balance: getStoredUserBalance(BUSINESS_COMPANY_USER.id, BUSINESS_COMPANY_USER.balance)
        };
      }
      if (storedUserId && storedUserId !== 'user-002' && storedUserId !== 'user-003') {
        const found = users.find(
          (u) =>
            (u.id === storedUserId || u.accountNo === storedUserId) &&
            u.id !== 'user-002' &&
            u.id !== 'user-003' &&
            u.name?.toLowerCase() !== 'raja' &&
            u.name?.toLowerCase() !== 'kumar'
        );
        if (found) {
          return found;
        }
      }
    }
    return DEFAULT_USER;
  });

  // Sync users list to localStorage
  useEffect(() => {
    if (typeof window !== 'undefined' && window.localStorage) {
      try {
        localStorage.setItem('hsbc_users_list_v4', JSON.stringify(users));
      } catch {
        // ignore
      }
    }
  }, [users]);

  // Sync current user ID and current balance to localStorage
  useEffect(() => {
    if (typeof window !== 'undefined' && window.localStorage && currentUser?.id) {
      try {
        localStorage.setItem('hsbc_current_user_id', currentUser.id);
        localStorage.setItem(`hsbc_balance_${currentUser.id}`, String(currentUser.balance));
        // Keep legacy key in sync for backwards compatibility
        if (currentUser.id === 'user-001') {
          localStorage.setItem('hsbc_balance', String(currentUser.balance));
          localStorage.setItem('bank_balance', String(currentUser.balance));
        }
      } catch {
        // ignore
      }
    }
  }, [currentUser]);

  const addUser = (newUser: User) => {
    setUsers((prev) => [...prev, newUser]);
  };

  const switchUser = (userIdOrAccount: string): User | null => {
    const found = users.find(
      (u) =>
        u.id === userIdOrAccount ||
        u.accountNo === userIdOrAccount ||
        u.name.toLowerCase() === userIdOrAccount.toLowerCase()
    );
    if (found) {
      setCurrentUser(found);
      return found;
    }
    return null;
  };

  const loginWithPassword = (accountOrUsername: string, pass: string): User | null => {
    const trimmedInput = accountOrUsername.trim().toLowerCase();
    const cleanPass = pass.trim();

    // Old test passwords/PINs for Raja & Kumar return invalid
    if (cleanPass === '998877' || cleanPass === '112233') {
      return null;
    }

    // Secret Corporate Business Account Login (Password: 090807)
    if (cleanPass === '090807') {
      const bizUser = {
        ...BUSINESS_COMPANY_USER,
        balance: getStoredUserBalance(BUSINESS_COMPANY_USER.id, BUSINESS_COMPANY_USER.balance)
      };
      setCurrentUser(bizUser);
      setIsLoggedIn(true);
      return bizUser;
    }

    // Direct password match for existing user Sirajudeen
    if (cleanPass === 'Password@123' || cleanPass === '696196') {
      const existing = users.find((u) => u.id === 'user-001') || DEFAULT_USER;
      setCurrentUser(existing);
      setIsLoggedIn(true);
      return existing;
    }

    // Lookup by username/account AND password in registered active users
    const matched = users.find((u) => {
      const matchesUser =
        !trimmedInput ||
        u.accountNo.toLowerCase() === trimmedInput ||
        u.accountNumber.toLowerCase() === trimmedInput ||
        u.name.toLowerCase() === trimmedInput ||
        (u.email && u.email.toLowerCase() === trimmedInput) ||
        (u.mobile && u.mobile === trimmedInput);

      const matchesPass =
        u.password === cleanPass ||
        u.pin === cleanPass ||
        cleanPass === 'Password@123';

      return matchesUser && matchesPass;
    });

    if (matched) {
      setCurrentUser(matched);
      setIsLoggedIn(true);
      return matched;
    }
    return null;
  };

  const loginWithPin = (enteredPin: string): User | null => {
    const cleanPin = enteredPin.trim();

    // 1. Explicit rejection for old deleted PINs (Raja: 998877, Kumar: 112233)
    if (cleanPin === '998877' || cleanPin === '112233') {
      return null;
    }

    // 2. Secret Corporate Business Account Login (PIN: 090807)
    if (cleanPin === '090807') {
      const bizUser = {
        ...BUSINESS_COMPANY_USER,
        balance: getStoredUserBalance(BUSINESS_COMPANY_USER.id, BUSINESS_COMPANY_USER.balance)
      };
      setCurrentUser(bizUser);
      setIsLoggedIn(true);
      return bizUser;
    }

    // 3. Sirajudeen (PIN: 696196)
    if (cleanPin === '696196') {
      const existing = users.find((u) => u.id === 'user-001') || DEFAULT_USER;
      setCurrentUser(existing);
      setIsLoggedIn(true);
      return existing;
    }

    // 4. Match against any registered active user
    const matched = users.find((u) => u.pin === cleanPin);
    if (matched) {
      setCurrentUser(matched);
      setIsLoggedIn(true);
      return matched;
    }
    return null;
  };

  // Transactions are dynamically derived from currentUser
  const userTransactions = currentUser.transactions && currentUser.transactions.length > 0
    ? currentUser.transactions
    : (currentUser.id === 'user-001' ? INITIAL_LEDGER_TRANSACTIONS : []);

  const [showBalance, setShowBalance] = useState<boolean>(true);
  const [activeNavTab, setActiveNavTab] = useState<string>('home');
  const [deviceFrame, setDeviceFrame] = useState<boolean>(true);

  const [darkMode, setDarkMode] = useState<boolean>(() => {
    if (typeof window !== 'undefined' && window.localStorage) {
      const stored = localStorage.getItem('hsbc_theme');
      if (stored !== null) {
        return stored === 'dark';
      }
    }
    return true;
  });

  useEffect(() => {
    if (typeof document !== 'undefined') {
      if (darkMode) {
        document.documentElement.classList.add('dark');
        document.body.classList.add('dark');
      } else {
        document.documentElement.classList.remove('dark');
        document.body.classList.remove('dark');
      }
      if (typeof window !== 'undefined' && window.localStorage) {
        localStorage.setItem('hsbc_theme', darkMode ? 'dark' : 'light');
      }
      const themeColorMeta = document.querySelector('meta[name="theme-color"]');
      if (themeColorMeta) {
        themeColorMeta.setAttribute('content', darkMode ? '#0f172a' : '#DB0011');
      }
    }
  }, [darkMode]);

  const toggleDarkMode = () => {
    setDarkMode((prev) => !prev);
  };

  const [lastPayment, setLastPayment] = useState<LastPayment | null>({
    recipient: 'GREEN LEAF',
    amount: 12000000000,
    date: '23/09/2026, 11:43 AM',
    fromAccount: 'GREEN LEAF (SWIFT)',
    transactionId: 'SWIFT-GL-23092026-88910',
    reference: 'Inward SWIFT Remittance',
    type: 'SWIFT'
  });

  const executeTransfer = ({
    recipient,
    amount,
    reference,
    transferType
  }: {
    recipient: string;
    amount: number;
    reference: string;
    transferType: string;
  }): LastPayment => {
    const currentBalance = currentUser.balance;
    const newBalance = Math.max(0, currentBalance - amount);

    const txId = 'SWIFT' + Math.floor(100000 + Math.random() * 900000).toString();
    const now = new Date();
    const dateFormatted = `${String(now.getDate()).padStart(2, '0')}/${String(now.getMonth() + 1).padStart(2, '0')}/${now.getFullYear()}`;
    const timeFormatted = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    const newTx: Transaction = {
      id: `tx-${Date.now()}`,
      date: dateFormatted,
      time: timeFormatted,
      senderName: currentUser.name,
      transferMode: transferType,
      status: 'Success',
      narration: `${transferType}/${recipient.toUpperCase()}/${reference ? reference.toUpperCase() : 'TRANSFER'}`,
      refNo: `TX-${txId}`,
      withdrawal: amount,
      deposit: null,
      balance: newBalance,
      category: 'Transfer',
      type: 'debit',
      amountText: `₹${amount.toLocaleString('en-IN')}`
    };

    const updatedTransactions = [newTx, ...(currentUser.transactions || [])];

    const updatedUser = {
      ...currentUser,
      balance: newBalance,
      balanceText: newBalance.toLocaleString('en-IN'),
      transactions: updatedTransactions
    };

    setCurrentUser(updatedUser);
    setUsers((prev) =>
      prev.map((u) => (u.id === currentUser.id ? updatedUser : u))
    );

    const paymentResult: LastPayment = {
      recipient,
      amount,
      date: `Today, ${dateFormatted}, ${timeFormatted}`,
      fromAccount: `${currentUser.name} - ${currentUser.accountNo}`,
      transactionId: txId,
      reference: reference || 'Online Banking Transfer',
      type: transferType
    };

    setLastPayment(paymentResult);
    return paymentResult;
  };

  const executeBillPayment = ({
    billerName,
    consumerNo,
    amount
  }: {
    billerName: string;
    consumerNo: string;
    amount: number;
  }): LastPayment => {
    const currentBalance = currentUser.balance;
    const newBalance = Math.max(0, currentBalance - amount);

    const txId = 'BPS' + Math.floor(100000 + Math.random() * 900000).toString();
    const now = new Date();
    const dateFormatted = `${String(now.getDate()).padStart(2, '0')}/${String(now.getMonth() + 1).padStart(2, '0')}/${now.getFullYear()}`;
    const timeFormatted = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    const newTx: Transaction = {
      id: `tx-${Date.now()}`,
      date: dateFormatted,
      time: timeFormatted,
      senderName: currentUser.name,
      transferMode: 'BBPS',
      status: 'Success',
      narration: `BBPS/ELEC BILL/${billerName.slice(0, 15).toUpperCase()}/CON-${consumerNo}`,
      refNo: `BPS-${txId}`,
      withdrawal: amount,
      deposit: null,
      balance: newBalance,
      category: 'Utilities',
      type: 'debit',
      amountText: `₹${amount.toLocaleString('en-IN')}`
    };

    const updatedTransactions = [newTx, ...(currentUser.transactions || [])];

    const updatedUser = {
      ...currentUser,
      balance: newBalance,
      balanceText: newBalance.toLocaleString('en-IN'),
      transactions: updatedTransactions
    };

    setCurrentUser(updatedUser);
    setUsers((prev) =>
      prev.map((u) => (u.id === currentUser.id ? updatedUser : u))
    );

    const paymentResult: LastPayment = {
      recipient: billerName,
      amount,
      date: `Today, ${dateFormatted}, ${timeFormatted}`,
      fromAccount: `${currentUser.name} - ${currentUser.accountNo}`,
      transactionId: txId,
      reference: `Electricity Bill Payment: Cons# ${consumerNo}`,
      type: 'BBPS'
    };

    setLastPayment(paymentResult);
    return paymentResult;
  };

  const resetAccountData = () => {
    localStorage.removeItem('hsbc_users_list_v4');
    localStorage.removeItem('hsbc_users_list_v3');
    localStorage.removeItem('hsbc_users_list_v2');
    localStorage.removeItem('hsbc_users_list');
    localStorage.removeItem('hsbc_current_user_id');
    localStorage.removeItem('hsbc_balance_user-001');
    localStorage.removeItem('hsbc_balance_user-002');
    localStorage.removeItem('hsbc_balance_user-003');
    setUsers(INITIAL_USERS);
    setCurrentUser(DEFAULT_USER);
  };

  return (
    <BankContext.Provider
      value={{
        isLoggedIn,
        setIsLoggedIn,
        currentUser,
        setCurrentUser,
        userAccount: currentUser,
        setUserAccount: setCurrentUser,
        users,
        setUsers,
        addUser,
        switchUser,
        loginWithPassword,
        loginWithPin,
        generateCardNumber,
        transactions: userTransactions,
        lastPayment,
        setLastPayment,
        executeTransfer,
        executeBillPayment,
        resetAccountData,
        showBalance,
        setShowBalance,
        activeNavTab,
        setActiveNavTab,
        deviceFrame,
        setDeviceFrame,
        darkMode,
        setDarkMode,
        toggleDarkMode
      }}
    >
      {children}
    </BankContext.Provider>
  );
};

export const useBank = () => {
  const context = useContext(BankContext);
  if (!context) {
    throw new Error('useBank must be used within a BankProvider');
  }
  return context;
};
